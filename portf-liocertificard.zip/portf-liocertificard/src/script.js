function alterarTema() {
  document.body.classList.toggle("dark");
}
